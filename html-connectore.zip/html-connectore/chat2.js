$(function(){
socket = io.connect('https://webrtc.telnet.center',{secure: true})

socket.on("new_message", (data) => {

})

socket.on('connect', function() {
	console.log('connect');
	connectmedia();
});

});