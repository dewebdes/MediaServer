$(function(){
socket = io.connect('https://ice.telnet.center',{secure: true})

socket.on('connect', function() {
	console.log('connect');
	//connectmedia();
	if(inwaitmod == "getstreaminfo"){
		inwaitmod = "";
		firstid = window.location.href.split("?")[1];
		socket.emit("getstreamdata",firstid);
	}
});


socket.on("setstreaminfo", (data) => {
	if(data.mic == true){
		if(data.cam == false){
			socket.emit("getmic",firstid);
			asStreamer();
			$('#streaminfo').html('Playing '+firstid);
		}else{
			$('#option_url').val($('#option_url').val().replace("{skid}",firstid));
			$('#flvsource').val($('#flvsource').val().replace("{skid}",firstid));

			$('#viddv').show();
			flvsourceinitialize();
			tmpint = setInterval(connectvid1,1000);

		}
	}
})

socket.on("addstream", (data) => {
	if(inwaitmod == "addstream"){
		inwaitmod = "";
		InitStream();
	}
	var el = $($('#streamlist p')[0]).clone();
	var htm = $(el).html();
	htm = htm.replace("{tit}",data.skid).replace("{tit}",data.skid);
	$(el).html(htm).show();
	$('#streamlist').append($(el));
})
socket.on("setliststreams", (data) => {
	for(var i=0;i<=data.length-1;i++){
		var el = $($('#streamlist p')[0]).clone();
		var htm = $(el).html();
		htm = htm.replace("{tit}",data[i].skid).replace("{tit}",data[i].skid);
		$(el).html(htm).show();
		$('#streamlist').append($(el));
	}
})

});