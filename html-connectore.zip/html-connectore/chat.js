
$(function(){
   	//make connection
	socket = io.connect('https://webrtc.telnet.center',{secure: true})

	//buttons and inputs
	
	//Emit message
	

	//Listen on new_message
	socket.on("new_message", (data) => {
		feedback.html('');
		message.val('');
		chatroom.append("<p class='message'>" + data.username + ": " + data.message + "</p>")
	})
	socket.on("registerme", (data) => {
		registermedone(data.dus,data.dres );
		
	})
	socket.on("register2done", (data) => {
		registermedone2(data.dus,data.dres );
		
	})
	socket.on("startlogin2done", (data) => {
		startlogin2done(data.dus,data.dres );
	})

	//Emit a username
	

	//Listen on typing
	socket.on('typing', (data) => {
		feedback.html("<p><i>" + data.username + " is typing a message..." + "</i></p>")
	})
	socket.on('connect', function() {
		if(firstid==""){firstid=socket.id;}
try{
getdisvid();
}catch(ex){}

		//console.log("***connect");
		try{
		        startRecording.disabled = false;
		    }catch(ex){}
		        socket.emit("getstreams",pgkey);
		    //}
    });
    socket.on('justgot', function(data) {
//console.log("***justgot");
    	//playback2(data);
    });

socket.on('addnewbuf', function(data) {
    	addnewbuf(data);
});

    
    socket.on('run1', function(data) {
return;
//console.log("***run1");
    	playback2(data);});
    socket.on('showstream', function(data) {
return;
    	for(var i=blbindx;i<=data.length-1;i++){
    		//if (buffer.updating) {
    		//	buffer.appendBuffer(data[i]);
    		//}else{
    			queue.push(data[i]);
    			if (queue.length > 0 && !buffer.updating) {
					buffer.appendBuffer(queue.shift());
				}

    		//}
    	}
    	const superBuffer = new Blob(queue, {type: 'video/webm'});
		video.src = null;
		video.srcObject = null;
		video.src = window.URL.createObjectURL(superBuffer);
		video.controls = true;
		video.play();


    	////console.log(data);
    	//varr[varr.length]=data;
    	blbindx = data.length;
    	clearInterval(intshow);
    	pgkey = window.location.href.split('?')[1]+"---"+blbindx;
    	jQuery('#tith').html(pgkey);
    	intshow = setInterval(getremainstream,1000);
    });
    socket.on('liststreams', function(data) {
	console.log(data);
	return;
		        var ar = data.split("#np#");
		        for(var i=0;i<=ar.length-1;i++){
		        	var nc = jQuery(jQuery('#streamlist p')[0]).clone();
		        	var htm = jQuery(nc).html();
		        	htm = htm.replace('{tit}',ar[i]);
		        	htm = htm.replace('{tit}',ar[i]);
		        	jQuery(nc).html(htm);
		        	jQuery(nc).show();
		        	if(jQuery('#streamlist').html().indexOf(ar[i]) == -1){
		        		//console.log(jQuery('#streamlist').html().indexOf(ar[i])+" - "+ar[i]);
		        		jQuery('#streamlist').append(jQuery(nc));
		        	}
		        }
    });
    
		    socket.on('merged', function(fileName) {
		        var href = (location.href.split('/').pop().length ? location.href.replace(location.href.split('/').pop(), '') : location.href);

		        href = href + '/uploads/' + fileName;

		        //console.log('got file ' + href);

		        cameraPreview.src = href
		        cameraPreview.play();
		        cameraPreview.muted = false;
		        cameraPreview.controls = true;
		    });

		    socket.on('ffmpeg-output', function(result) {
		        if (parseInt(result) >= 100) {
		            progressBar.parentNode.style.display = 'none';
		            return;
		        }
		        progressBar.parentNode.style.display = 'block';
		        progressBar.value = result;
		        percentage.innerHTML = 'Ffmpeg Progress ' + result + "%";
		    });

		    socket.on('ffmpeg-error', function(error) {
		        alert(error);
		    });

});


